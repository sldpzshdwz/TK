#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
//152 49
int main()
{
	freopen("map.tk","w",stdout);
	for (int j=1;j<=156;j++)printf ("*");printf("\n");
	for (int i=1;i<=49;i++){
		printf("||");
		
		for (int j=1;j<=152;j++){if (i%10==0 && (((i/10)%2==1 && j<=132)||((i/10)%2==0 && j>=20)))
		printf("*");else printf(" ");}
		printf("||\n");
	}
	for (int j=1;j<=156;j++)printf ("*");printf("\n");
	return 0;
}

